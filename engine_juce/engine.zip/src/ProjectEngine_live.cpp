#include "audioapp/MidiClipPlayback.hpp"
#include "audioapp/ProjectEngine.hpp"

#include <algorithm>
#include <cmath>

namespace audioapp {

namespace {

double quantizeCaptureBeat(double beat, double grid = 0.25) {
    if (grid <= 0.0) {
        return beat;
    }
    return std::round(beat / grid) * grid;
}

} // namespace

bool ProjectEngine::buildLiveInstrumentForTrack(const Track& track,
                                                LiveInstrumentSnapshot& out) const {
    PlaybackBuildContext context{sampleBank_};
    context.wavetableBank = wavetableBank_;
    for (const auto& device : track.devices) {
        if (deviceRegistry_.buildLiveInstrument(device, context, out)) {
            return true;
        }
    }
    return false;
}

double ProjectEngine::sampleTimeToCaptureBeat(uint64_t sampleTime) const {
    if (!captureActive_ || sampleTime < captureStartSample_) {
        return 0.0;
    }
    const double seconds =
        static_cast<double>(sampleTime - captureStartSample_) / 48000.0;
    return seconds * static_cast<double>(transport_.bpm()) / 60.0;
}

bool ProjectEngine::setRecordArmed(bool armed) {
    const juce::ScopedWriteLock lock(mutex_);
    recordArmed_ = armed;
    if (!armed) {
        captureActive_ = false;
        captureEventHead_ = 0;
        captureEventCount_ = 0;
    }
    return true;
}

bool ProjectEngine::noteOn(int pitch, float velocity) {
    const juce::ScopedWriteLock lock(mutex_);
    if (trackRepo_.selectedTrackId().empty()) {
        return false;
    }
    Track* track = trackRepo_.findTrack(trackRepo_.selectedTrackId());
    if (track == nullptr) {
        return false;
    }

    LiveInstrumentSnapshot instrument{};
    if (!buildLiveInstrumentForTrack(*track, instrument)) {
        return false;
    }

    // A Sampler with no loaded sample is silent — treat as no playable instrument
    if (instrument.kind == LiveInstrumentKind::Sampler &&
        (instrument.samplerPcm == nullptr || instrument.samplerFrameCount <= 0)) {
        return false;
    }

    liveMixer_.noteOn(instrument, pitch, velocity);
    // Don't call retriggerOnNote() — live pad input shares the global
    // retrigger generation with the arrangement LFO render path, causing
    // unwanted envelope resets on arrangement LFOs (staccato/gate artifacts).

    if (recordArmed_) {
        const uint64_t now = liveMixer_.sampleClock();
        if (!captureActive_) {
            captureActive_ = true;
            captureStartSample_ = now;
            captureStartPlayheadBeat_ = transport_.playheadBeats();
            captureEventHead_ = 0;
            captureEventCount_ = 0;
        }
        if (captureEventCount_ < kMaxCaptureEvents) {
            const int idx = (captureEventHead_ + captureEventCount_) % kMaxCaptureEvents;
            captureEvents_[idx] = CaptureEvent{CaptureEvent::Type::NoteOn, pitch, velocity, now};
            ++captureEventCount_;
        }
    }
    return true;
}

bool ProjectEngine::noteOff(int pitch) {
    const juce::ScopedWriteLock lock(mutex_);
    liveMixer_.noteOff(pitch);
    if (recordArmed_ && captureActive_) {
        if (captureEventCount_ < kMaxCaptureEvents) {
            const int idx = (captureEventHead_ + captureEventCount_) % kMaxCaptureEvents;
            captureEvents_[idx] = CaptureEvent{
                CaptureEvent::Type::NoteOff,
                pitch,
                0.0f,
                liveMixer_.sampleClock(),
            };
            ++captureEventCount_;
        }
    }
    return true;
}

void ProjectEngine::allNotesOff() {
    const juce::ScopedWriteLock lock(mutex_);
    liveMixer_.allNotesOff();
}

void ProjectEngine::setLivePitchBend(float bend) noexcept {
    livePitchBend_.store(bend, std::memory_order_relaxed);
}

void ProjectEngine::setLiveModulation(float mod) noexcept {
    liveModulation_.store(mod, std::memory_order_relaxed);
}

void ProjectEngine::clearCapture() {
    const juce::ScopedWriteLock lock(mutex_);
    captureEventHead_ = 0;
    captureEventCount_ = 0;
    captureActive_ = false;
}

bool ProjectEngine::commitCapture() {
    std::string trackId;
    double clipStart = 0.0;
    double clipLength = 4.0;
    std::vector<MidiNoteState> committed;

    {
        const juce::ScopedWriteLock lock(mutex_);
        if (!captureActive_ || captureEventCount_ == 0 || trackRepo_.selectedTrackId().empty()) {
            return false;
        }

        struct OpenNote {
            int pitch = 60;
            float velocity = 100.0f;
            double startBeat = 0.0;
        };
        std::vector<OpenNote> open;

        for (int i = 0; i < captureEventCount_; ++i) {
            const int idx = (captureEventHead_ + i) % kMaxCaptureEvents;
            const auto& event = captureEvents_[idx];
            const double beat = quantizeCaptureBeat(sampleTimeToCaptureBeat(event.sampleTime));
            if (event.type == CaptureEvent::Type::NoteOn) {
                open.push_back(OpenNote{event.pitch, event.velocity, beat});
            } else {
                for (auto it = open.begin(); it != open.end(); ++it) {
                    if (it->pitch != event.pitch) {
                        continue;
                    }
                    const double endBeat =
                        quantizeCaptureBeat(sampleTimeToCaptureBeat(event.sampleTime));
                    double duration = endBeat - it->startBeat;
                    if (duration < 0.25) {
                        duration = 0.25;
                    }
                    committed.push_back(MidiNoteState{
                        it->pitch,
                        it->startBeat,
                        duration,
                        it->velocity,
                    });
                    open.erase(it);
                    break;
                }
            }
        }

        for (const auto& note : open) {
            committed.push_back(MidiNoteState{note.pitch, note.startBeat, 0.5, note.velocity});
        }

        if (committed.empty()) {
            captureEventHead_ = 0;
            captureEventCount_ = 0;
            captureActive_ = false;
            return false;
        }

        double maxEnd = 0.0;
        for (const auto& note : committed) {
            maxEnd = std::max(maxEnd, note.startBeat + note.durationBeats);
        }
        clipLength = std::max(4.0, std::ceil(maxEnd / 4.0) * 4.0);
        // Use the playhead position at capture start, not at commit time,
        // so the recorded clip aligns correctly with the timeline.
        clipStart = captureStartPlayheadBeat_;
        trackId = trackRepo_.selectedTrackId();

        captureEventHead_ = 0;
        captureEventCount_ = 0;
        captureActive_ = false;
    }

    const std::string clipId = createMidiClip(trackId, clipStart, clipLength);
    if (clipId.empty()) {
        return false;
    }
    return setMidiClipNotes(clipId, committed);
}

void ProjectEngine::readLiveMix(float* monoOut, int numFrames, double sampleRate) noexcept {
    liveMixer_.readMix(monoOut, numFrames, sampleRate);
    liveMixer_.advanceSampleClock(numFrames);
}

} // namespace audioapp
