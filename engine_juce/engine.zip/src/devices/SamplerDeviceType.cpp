#include "audioapp/devices/SamplerDeviceType.hpp"

#include "audioapp/SampleBank.hpp"
#include "audioapp/devices/DeviceTypeIds.hpp"
#include "audioapp/devices/instances/SamplerModel.hpp"
#include "audioapp/devices/processors/SamplerProcessor.hpp"

#include <juce_core/juce_core.h>
#include <algorithm>
#include <cmath>

#include "audioapp/devices/DeviceStripParams.hpp"

namespace audioapp {
namespace {

void resolveSampleFrames(const SamplerModel& instance,
                         const PlaybackBuildContext& context,
                         SamplerParams& params) {
    params.samplerPcm = nullptr;
    params.samplerFrameCount = 0;
    params.samplerPcmSampleRate = 48000.0;
    params.trimStartFrame = 0;
    params.trimEndFrame = 0;
    params.regionStartFrame = 0;
    params.regionEndFrame = 0;

    if (context.sampleBank == nullptr || instance.sampleId.empty()) {
        return;
    }
    const auto* sample = context.sampleBank->findSample(instance.sampleId);
    if (sample == nullptr || sample->pcm.empty()) {
        return;
    }

    params.samplerPcm = sample->pcm.data();
    params.samplerFrameCount = static_cast<int>(sample->pcm.size());
    params.samplerPcmSampleRate = sample->sampleRate;
    const int frameCount = params.samplerFrameCount;
    params.trimStartFrame = std::clamp(static_cast<int>(instance.trimStartSec * sample->sampleRate),
                                       0,
                                       std::max(0, frameCount - 1));
    params.trimEndFrame = instance.trimEndSec > 0.0f
        ? std::clamp(static_cast<int>(instance.trimEndSec * sample->sampleRate),
                     params.trimStartFrame + 1,
                     frameCount)
        : frameCount;
    if (instance.regionEndSec > 0.0f) {
        const int rawStart = static_cast<int>(instance.regionStartSec * sample->sampleRate);
        params.regionStartFrame = std::clamp(rawStart,
                                             params.trimStartFrame,
                                             params.trimEndFrame - 1);
        const int rawEnd = static_cast<int>(instance.regionEndSec * sample->sampleRate);
        params.regionEndFrame = std::clamp(rawEnd,
                                           params.regionStartFrame + 1,
                                           params.trimEndFrame);
    }
}

void resolveLiveSampleFrames(const SamplerModel& instance,
                             const PlaybackBuildContext& context,
                             LiveInstrumentSnapshot& out) {
    out.samplerPcm = nullptr;
    out.samplerFrameCount = 0;
    out.samplerPcmSampleRate = 48000.0;
    out.trimStartFrame = 0;
    out.trimEndFrame = 0;
    out.regionStartFrame = 0;
    out.regionEndFrame = 0;

    if (context.sampleBank == nullptr || instance.sampleId.empty()) {
        return;
    }
    const auto* sample = context.sampleBank->findSample(instance.sampleId);
    if (sample == nullptr || sample->pcm.empty()) {
        return;
    }

    out.samplerPcm = sample->pcm.data();
    out.samplerFrameCount = static_cast<int>(sample->pcm.size());
    out.samplerPcmSampleRate = sample->sampleRate;
    const double trimStartSec = std::max(0.0, static_cast<double>(instance.trimStartSec));
    const double trimEndSec = instance.trimEndSec > trimStartSec
                                  ? static_cast<double>(instance.trimEndSec)
                                  : static_cast<double>(sample->pcm.size()) / sample->sampleRate;
    out.trimStartFrame = static_cast<int>(trimStartSec * sample->sampleRate);
    out.trimEndFrame = static_cast<int>(trimEndSec * sample->sampleRate);
    if (out.trimEndFrame <= out.trimStartFrame) {
        out.trimEndFrame = out.samplerFrameCount;
    }
    if (instance.regionEndSec > 0.0f) {
        const int rawRegStart = static_cast<int>(instance.regionStartSec * sample->sampleRate);
        out.regionStartFrame = std::clamp(rawRegStart, out.trimStartFrame, out.trimEndFrame - 1);
        const int rawRegEnd = static_cast<int>(instance.regionEndSec * sample->sampleRate);
        out.regionEndFrame = std::clamp(rawRegEnd, out.regionStartFrame + 1, out.trimEndFrame);
    }
}

} // namespace

std::string SamplerDeviceType::typeId() const {
    return device_types::kSampler;
}

DeviceSlot SamplerDeviceType::createDefault(const std::string& deviceId) const {
    DeviceSlot slot;
    slot.id = deviceId;
    slot.config.typeId = typeId();
    slot.config.instance = SamplerModel{};

    slot.config.inputPanel = EmptyPanel{};
    slot.config.outputPanel = StereoOutputPanel{};
    slot.config.bypassed = false;
    return slot;
}

DeviceParameterResult SamplerDeviceType::setParameter(DeviceSlot& slot,
                                                      std::string_view parameterId,
                                                      float value) const {
    DeviceParameterResult result;
    if (device_strip::setStripParameter(slot, parameterId, value)) {
        result.handled = true;
        return result;
    }

    auto& instance = std::get<SamplerModel>(slot.config.instance);
    const uint16_t id = paramIdFromString(parameterId);
    if (id == static_cast<uint16_t>(-1))
        return result;
    switch (static_cast<SamplerParam>(id)) {
    case SamplerParam::Attack:          instance.attack = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::Decay:           instance.decay = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::Release:         instance.release = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::Sustain:         instance.sustain = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::FilterCutoff:    instance.filterCutoff = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::FilterQ:         instance.filterQ = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::FilterMode:      instance.filterMode = std::clamp(static_cast<int>(std::lround(value)), 0, 3); break;
    case SamplerParam::FilterEnvAmount: instance.filterEnvAmount = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::FilterAttack:    instance.filterAttack = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::FilterDecay:     instance.filterDecay = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::FilterSustain:   instance.filterSustain = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::FilterRelease:   instance.filterRelease = std::clamp(value, 0.0f, 1.0f); break;
    case SamplerParam::TrimStartSec:    instance.trimStartSec = std::max(0.0f, value); break;
    case SamplerParam::TrimEndSec:      instance.trimEndSec = std::max(0.0f, value); break;
    case SamplerParam::RegionStartSec:  instance.regionStartSec = std::max(0.0f, value); break;
    case SamplerParam::RegionEndSec:    instance.regionEndSec = std::max(0.0f, value); break;
    case SamplerParam::RootPitch:       instance.rootPitch = std::clamp(value, 0.0f, 127.0f); break;
    case SamplerParam::RootFineTune:    instance.rootFineTune = std::clamp(value, -100.0f, 100.0f); break;
    case SamplerParam::PlaybackMode:    instance.playbackMode = std::clamp(static_cast<int>(std::lround(value)), 0, 2); break;
    default:
        return result;
    }

    result.handled = true;
    return result;
}

bool SamplerDeviceType::setStringParameter(DeviceSlot& slot,
                                           std::string_view parameterId,
                                           const std::string& value,
                                           const PlaybackBuildContext& context) const {
    if (parameterId != "sampleId") {
        return false;
    }
    if (!value.empty() && context.sampleBank != nullptr &&
        context.sampleBank->findSample(value) == nullptr) {
        return false;
    }
    std::get<SamplerModel>(slot.config.instance).sampleId = value;
    return true;
}

std::vector<std::string_view> SamplerDeviceType::modulatableParams() const {
    return {"gain", "pan", "attack", "decay", "sustain", "release", "filterCutoff", "filterQ",
            "filterEnvAmount", "filterAttack", "filterDecay", "filterSustain", "filterRelease",
            "rootPitch", "rootFineTune"};
}

void SamplerDeviceType::buildPlaybackNode(const DeviceSlot& slot,
                                          const PlaybackBuildContext& context,
                                          DeviceNodePlayback& out) const {
    const auto& instance = std::get<SamplerModel>(slot.config.instance);
    SamplerParams params;
    params.attack = instance.attack;
    params.decay = instance.decay;
    params.sustain = instance.sustain;
    params.release = instance.release;
    params.filterCutoff = instance.filterCutoff;
    params.filterQ = instance.filterQ;
    params.filterMode = instance.filterMode;
    params.filterEnvAmount = instance.filterEnvAmount;
    params.filterAttack = instance.filterAttack;
    params.filterDecay = instance.filterDecay;
    params.filterSustain = instance.filterSustain;
    params.filterRelease = instance.filterRelease;
    params.rootPitch = static_cast<int>(std::lround(instance.rootPitch));
    params.rootFineTune = instance.rootFineTune;
    params.playbackMode = instance.playbackMode;
    resolveSampleFrames(instance, context, params);
    out.kind = DeviceNodeKind::Sampler;
    out.params = params;
}

bool SamplerDeviceType::buildLiveInstrument(const DeviceSlot& slot,
                                            const PlaybackBuildContext& context,
                                            LiveInstrumentSnapshot& out) const {
    const auto& instance = std::get<SamplerModel>(slot.config.instance);
    out = LiveInstrumentSnapshot{};
    out.kind = LiveInstrumentKind::Sampler;
    out.gain = std::get<StereoOutputPanel>(slot.config.outputPanel).gain;
    out.rootPitch = static_cast<int>(std::lround(instance.rootPitch));
    out.rootFineTune = instance.rootFineTune;
    out.playbackMode = instance.playbackMode;
    out.attack = instance.attack;
    out.decay = instance.decay;
    out.sustain = instance.sustain;
    out.release = instance.release;
    out.filterCutoff = instance.filterCutoff;
    out.filterQ = instance.filterQ;
    out.filterMode = instance.filterMode;
    out.filterEnvAmount = instance.filterEnvAmount;
    out.filterAttack = instance.filterAttack;
    out.filterDecay = instance.filterDecay;
    out.filterSustain = instance.filterSustain;
    out.filterRelease = instance.filterRelease;
    resolveLiveSampleFrames(instance, context, out);
    return true;
}

juce::var SamplerDeviceType::slotToVar(const DeviceSlot& slot) const {
    auto* parameters = new juce::DynamicObject();
    const auto& inst = std::get<SamplerModel>(slot.config.instance);

    parameters->setProperty("sampleId", juce::String::fromUTF8(inst.sampleId.c_str()));
    parameters->setProperty("attack", static_cast<double>(inst.attack));
    parameters->setProperty("decay", static_cast<double>(inst.decay));
    parameters->setProperty("sustain", static_cast<double>(inst.sustain));
    parameters->setProperty("release", static_cast<double>(inst.release));
    parameters->setProperty("filterCutoff", static_cast<double>(inst.filterCutoff));
    parameters->setProperty("filterQ", static_cast<double>(inst.filterQ));
    parameters->setProperty("filterMode", inst.filterMode);
    parameters->setProperty("filterEnvAmount", static_cast<double>(inst.filterEnvAmount));
    parameters->setProperty("filterAttack", static_cast<double>(inst.filterAttack));
    parameters->setProperty("filterDecay", static_cast<double>(inst.filterDecay));
    parameters->setProperty("filterSustain", static_cast<double>(inst.filterSustain));
    parameters->setProperty("filterRelease", static_cast<double>(inst.filterRelease));
    parameters->setProperty("trimStartSec", static_cast<double>(inst.trimStartSec));
    parameters->setProperty("trimEndSec", static_cast<double>(inst.trimEndSec));
    parameters->setProperty("regionStartSec", static_cast<double>(inst.regionStartSec));
    parameters->setProperty("regionEndSec", static_cast<double>(inst.regionEndSec));
    parameters->setProperty("rootPitch", static_cast<double>(inst.rootPitch));
    parameters->setProperty("rootFineTune", static_cast<double>(inst.rootFineTune));
    parameters->setProperty("playbackMode", inst.playbackMode);

    auto* object = new juce::DynamicObject();
    object->setProperty("id", juce::String::fromUTF8(slot.id.c_str()));
    object->setProperty("type", juce::String::fromUTF8(typeId().c_str()));

    auto* outObj = new juce::DynamicObject();
    const auto& panel = std::get<StereoOutputPanel>(slot.config.outputPanel);
    outObj->setProperty("type", "stereo");
    outObj->setProperty("gain", static_cast<double>(panel.gain));
    outObj->setProperty("pan", static_cast<double>(panel.pan));
    object->setProperty("outputPanel", juce::var(outObj));

    auto* inObj = new juce::DynamicObject();
    inObj->setProperty("type", "empty");
    object->setProperty("inputPanel", juce::var(inObj));

    object->setProperty("bypass", slot.config.bypassed ? 1.0 : 0.0);
    object->setProperty("parameters", juce::var(parameters));
    return juce::var(object);
}

DeviceSlot SamplerDeviceType::varToSlot(const juce::var& obj) const {
    DeviceSlot slot;
    if (const auto* object = obj.getDynamicObject()) {
        slot.id = object->getProperty("id").toString().toStdString();
        slot.config.typeId = object->getProperty("type").toString().toStdString();

        const auto outputPanelVar = object->getProperty("outputPanel");
        bool hasPanel = outputPanelVar.isObject();
        if (hasPanel) {
            const auto* panel = outputPanelVar.getDynamicObject();
            StereoOutputPanel sp;
            sp.gain = static_cast<float>(static_cast<double>(panel->getProperty("gain")));
            sp.pan = static_cast<float>(static_cast<double>(panel->getProperty("pan")));
            slot.config.outputPanel = sp;

        }

        slot.config.bypassed = object->getProperty("bypass").isDouble()
            ? (static_cast<float>(static_cast<double>(object->getProperty("bypass"))) >= 0.5f)
            : false;

        const auto params = object->getProperty("parameters");
        if (const auto* p = params.getDynamicObject()) {
            auto readFloat = [&](const char* key, float fallback) -> float {
                const auto v = p->getProperty(key);
                if (v.isDouble() || v.isInt() || v.isInt64())
                    return static_cast<float>(static_cast<double>(v));
                return fallback;
            };
            auto readString = [&](const char* key) -> std::string {
                const auto v = p->getProperty(key);
                if (v.isString())
                    return v.toString().toStdString();
                return {};
            };

            if (!hasPanel) {
                const float oldGain = readFloat("gain", 1.0f);
                const float oldPan = readFloat("pan", 0.5f);
                slot.config.outputPanel = StereoOutputPanel{oldGain, oldPan};
                slot.config.bypassed = readFloat("bypass", 0.0f) >= 0.5f;
            }

            SamplerModel inst;
            inst.sampleId = readString("sampleId");
            inst.attack = readFloat("attack", 0.01f);
            inst.decay = readFloat("decay", 0.3f);
            inst.sustain = readFloat("sustain", 0.7f);
            inst.release = readFloat("release", 0.4f);
            inst.filterCutoff = readFloat("filterCutoff", 1.0f);
            inst.filterQ = readFloat("filterQ", 0.35f);
            inst.filterMode = static_cast<int>(readFloat("filterMode", 0.0f));
            inst.filterEnvAmount = readFloat("filterEnvAmount", 0.5f);
            inst.filterAttack = readFloat("filterAttack", 0.05f);
            inst.filterDecay = readFloat("filterDecay", 0.35f);
            inst.filterSustain = readFloat("filterSustain", 0.4f);
            inst.filterRelease = readFloat("filterRelease", 0.45f);
            inst.trimStartSec = readFloat("trimStartSec", 0.0f);
            inst.trimEndSec = readFloat("trimEndSec", 0.0f);
            inst.regionStartSec = readFloat("regionStartSec", 0.0f);
            inst.regionEndSec = readFloat("regionEndSec", 0.0f);
            inst.rootPitch = readFloat("rootPitch", 60.0f);
            inst.rootFineTune = std::clamp(readFloat("rootFineTune", 0.0f), -100.0f, 100.0f);
            if (p->hasProperty("playbackMode")) {
                inst.playbackMode = static_cast<int>(readFloat("playbackMode", 0.0f));
            } else {
                inst.playbackMode = inst.regionEndSec > 0.0f ? 1 : 0;
            }
            slot.config.instance = inst;
        }
    }
    return slot;
}

DeviceProcessor* SamplerDeviceType::createProcessor(ProcessorArena& arena) const {
    return arena.template emplace<SamplerProcessor>();
}

DeviceNodeKind SamplerDeviceType::kind() const noexcept { return DeviceNodeKind::Sampler; }

uint16_t SamplerDeviceType::paramIdFromString(std::string_view name) const noexcept {
    if (name == "filterCutoff") return static_cast<uint16_t>(SamplerParam::FilterCutoff);
    if (name == "filterQ") return static_cast<uint16_t>(SamplerParam::FilterQ);
    if (name == "attack") return static_cast<uint16_t>(SamplerParam::Attack);
    if (name == "decay") return static_cast<uint16_t>(SamplerParam::Decay);
    if (name == "sustain") return static_cast<uint16_t>(SamplerParam::Sustain);
    if (name == "release") return static_cast<uint16_t>(SamplerParam::Release);
    if (name == "rootPitch") return static_cast<uint16_t>(SamplerParam::RootPitch);
    if (name == "rootFineTune") return static_cast<uint16_t>(SamplerParam::RootFineTune);
    if (name == "filterEnvAmount") return static_cast<uint16_t>(SamplerParam::FilterEnvAmount);
    if (name == "filterAttack") return static_cast<uint16_t>(SamplerParam::FilterAttack);
    if (name == "filterDecay") return static_cast<uint16_t>(SamplerParam::FilterDecay);
    if (name == "filterSustain") return static_cast<uint16_t>(SamplerParam::FilterSustain);
    if (name == "filterRelease") return static_cast<uint16_t>(SamplerParam::FilterRelease);
    if (name == "filterMode") return static_cast<uint16_t>(SamplerParam::FilterMode);
    if (name == "trimStartSec") return static_cast<uint16_t>(SamplerParam::TrimStartSec);
    if (name == "trimEndSec") return static_cast<uint16_t>(SamplerParam::TrimEndSec);
    if (name == "regionStartSec") return static_cast<uint16_t>(SamplerParam::RegionStartSec);
    if (name == "regionEndSec") return static_cast<uint16_t>(SamplerParam::RegionEndSec);
    if (name == "playbackMode") return static_cast<uint16_t>(SamplerParam::PlaybackMode);
    return static_cast<uint16_t>(-1);
}

std::string_view SamplerDeviceType::paramIdToString(uint16_t localId) const noexcept {
    switch (static_cast<SamplerParam>(localId)) {
    case SamplerParam::FilterCutoff: return "filterCutoff";
    case SamplerParam::FilterQ: return "filterQ";
    case SamplerParam::Attack: return "attack";
    case SamplerParam::Decay: return "decay";
    case SamplerParam::Sustain: return "sustain";
    case SamplerParam::Release: return "release";
    case SamplerParam::RootPitch: return "rootPitch";
    case SamplerParam::RootFineTune: return "rootFineTune";
    case SamplerParam::FilterEnvAmount: return "filterEnvAmount";
    case SamplerParam::FilterAttack: return "filterAttack";
    case SamplerParam::FilterDecay: return "filterDecay";
    case SamplerParam::FilterSustain: return "filterSustain";
    case SamplerParam::FilterRelease: return "filterRelease";
    case SamplerParam::FilterMode: return "filterMode";
    case SamplerParam::TrimStartSec: return "trimStartSec";
    case SamplerParam::TrimEndSec: return "trimEndSec";
    case SamplerParam::RegionStartSec: return "regionStartSec";
    case SamplerParam::RegionEndSec: return "regionEndSec";
    case SamplerParam::PlaybackMode: return "playbackMode";
    default: return "";
    }
}

std::span<const ParamDescriptor> SamplerDeviceType::paramDescriptors() const noexcept {
    static constexpr ParamDescriptor kParams[] = {
        {static_cast<uint16_t>(SamplerParam::FilterCutoff), "filterCutoff", "Filter Cutoff", 1.0f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::FilterQ), "filterQ", "Filter Q", 0.5f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::Attack), "attack", "Attack", 0.01f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::Decay), "decay", "Decay", 0.1f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::Sustain), "sustain", "Sustain", 1.0f, 0.0f, 1.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::Release), "release", "Release", 0.2f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::RootPitch), "rootPitch", "Root Pitch", 60.0f, 0.0f, 127.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::RootFineTune), "rootFineTune", "Fine Tune", 0.0f, -100.0f, 100.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::FilterEnvAmount), "filterEnvAmount", "Filter Env", 0.5f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::FilterAttack), "filterAttack", "Flt Attack", 0.05f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::FilterDecay), "filterDecay", "Flt Decay", 0.35f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::FilterSustain), "filterSustain", "Flt Sustain", 0.4f, 0.0f, 1.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::FilterRelease), "filterRelease", "Flt Release", 0.45f, 0.0f, 1.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::FilterMode), "filterMode", "Filter Mode", 0.0f, 0.0f, 3.0f, true, true},
        {static_cast<uint16_t>(SamplerParam::TrimStartSec), "trimStartSec", "Trim Start", 0.0f, 0.0f, 86400.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::TrimEndSec), "trimEndSec", "Trim End", 0.0f, 0.0f, 86400.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::RegionStartSec), "regionStartSec", "Region Start", 0.0f, 0.0f, 86400.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::RegionEndSec), "regionEndSec", "Region End", 0.0f, 0.0f, 86400.0f, true, false},
        {static_cast<uint16_t>(SamplerParam::PlaybackMode), "playbackMode", "Playback Mode", 0.0f, 0.0f, 2.0f, true, false},
    };
    return kParams;
}

bool SamplerDeviceType::usesDspAutomationSubBlocks() const noexcept { return true; }

} // namespace audioapp
