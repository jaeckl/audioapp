#pragma once

#include <string>

namespace audioapp {

struct SamplerModel {
    std::string sampleId;
    float attack = 0.01f;
    float decay = 0.3f;
    float sustain = 0.7f;
    float release = 0.4f;
    float filterCutoff = 1.0f;
    float filterQ = 0.35f;
    int filterMode = 0;
    float filterEnvAmount = 0.5f;
    float filterAttack = 0.05f;
    float filterDecay = 0.35f;
    float filterSustain = 0.4f;
    float filterRelease = 0.45f;
    float trimStartSec = 0.0f;
    float trimEndSec = 0.0f;
    float regionStartSec = 0.0f;
    float regionEndSec = 0.0f;
    float rootPitch = 60.0f;
    float rootFineTune = 0.0f;
    int playbackMode = 0;
};

} // namespace audioapp